#include <vector>
#include <map>
#include <tuple>
#include <stdexcept>
#include <cuda.h>

/* * ------------------------------------------------------------
 * 1. 物理页池管理 (Physical Page Pool Management)
 * ------------------------------------------------------------
 * 这些函数负责从预先分配好的“空闲页池”中取出物理页句柄。
 * 类似于操作系统的 PMM (Physical Memory Manager)。
 */

// 从 CUDA VMM 后端的页池中取出一个物理页句柄
// 这里的 CUPage 通常是 CUmemGenericAllocationHandle
inline CUPage pop_cuda_page() {
    // 安全检查：防止显存耗尽（OOM）
    if (cuda_pages.empty())
        throw std::runtime_error("***** page pool is empty *****");

    // LIFO (后进先出) 策略取出最后一页
    // 使用 vector 作为栈，性能最高
    CUPage page = cuda_pages.back();
    cuda_pages.pop_back();
    return page;
}

/* * ------------------------------------------------------------
 * 2. 宏定义：核心显存操作 (Core Memory Operations)
 * ------------------------------------------------------------
 * 使用宏而非函数是为了方便内联代码块，且便于处理不同后端的条件编译逻辑。
 */

// ------------------------------------------------------------
// 清理/复位整个 KV Cache 系统
// ------------------------------------------------------------
// 1. 逻辑解绑：释放所有请求占用的映射
// 2. 物理释放：调用底层 API 销毁物理句柄
// 3. 容器清空：清空页池 vector
#define DO_KVCACHE_CLEANUP(page_size) \
    do { \
        /* 遍历所有可能的请求槽位，释放它们当前持有的页 */ \
        for (int reqId = 0; reqId < max_batch_size; reqId++) \
            release_kvcache_pages_all(reqId); \
        /* 根据后端类型清理全局物理页池 */ \
        do_cuda_kvcache_cleanup(); /* 调用 cuMemRelease 等 */ \
        cuda_pages.clear(); \
    } while (0)

// ------------------------------------------------------------
// 建立映射：将物理页挂载到虚拟地址
// ------------------------------------------------------------
// reqId: 请求 ID
// layer_idx: Transformer 层索引
// req_offset: 虚拟地址偏移量 (该请求的第几个 Block)
// kcache_ptr/vcache_ptr: 显存基地址指针
#define MAP_PAGES(reqId, layer_idx, req_offset, kcache_ptr, vcache_ptr, page_size) \
    do { \
        /* 1. 从池中取出两个物理页 (一个给 K，一个给 V) */ \
        CUPage k_page = pop_cuda_page(); \
        CUPage v_page = pop_cuda_page(); \
        /* 2. 调用 map_cuda_pages 执行 cuMemMap 映射操作 */ \
        /* 注意：这里并没有将映射关系存入 cuda_pagemap，需要在 map 函数内部或之后处理 */ \
        map_cuda_pages(reqId, layer_idx, req_offset, kcache_ptr, vcache_ptr, k_page, v_page); \
    } while (0)

// ------------------------------------------------------------
// 解除映射与回收：显存归还逻辑
// ------------------------------------------------------------
// 这是一个“逆操作”：
// 1. cuMemUnmap: 解除虚拟地址与物理地址的绑定 (GPU 无法再访问该地址)
// 2. 查表: 找回当初映射在这个地址上的物理页句柄
// 3. push_back: 将物理页归还到空闲池，供后续复用
#define UNMAP_PAGES(reqId, layer_idx, req_offset, kcache_ptr, vcache_ptr, page_size) \
    do { \
        /* 1. 解除虚拟内存映射 */ \
        /* 注意：这里只解除了映射，物理显存并未被释放(Destroy)，只是变成了“游离”状态 */ \
        CHECK_CUDA(cuMemUnmap(kcache_ptr + req_offset, page_size)); \
        CHECK_CUDA(cuMemUnmap(vcache_ptr + req_offset, page_size)); \
        \
        /* 2. 查找元数据表，找回物理页句柄 */ \
        /* Key 是 (ReqID, Offset, Layer) 的三元组 */ \
        std::pair pages = cuda_pagemap[std::make_tuple(reqId, req_offset, layer_idx)]; \
        \
        /* 3. 将物理页归还到池中 (Recycle) */ \
        cuda_pages.push_back(pages.first);  /* 归还 K 页 */ \
        cuda_pages.push_back(pages.second); /* 归还 V 页 */ \
        \
        /* 4. 删除元数据记录 */ \
        cuda_pagemap.erase(std::make_tuple(reqId, req_offset, layer_idx)); \
    } while (0)

// ------------------------------------------------------------
// 共享映射 (Prefix Sharing / Prompt Cache)
// ------------------------------------------------------------
// 核心优化：将 *同一对* 物理页映射到 *所有* 请求的相同位置。
// 场景：所有用户共享同一个 System Prompt（如 "You are a helpful AI..."）。
// 效果：物理显存只占用 1 份，但 N 个请求都能读取到相同的数据，节省 N-1 份显存。
#define MAP_COMMON_PAGES(layer_idx, kcache_ptr, vcache_ptr, page_size) \
    do { \
        /* 1. 只分配一次物理页 (One allocation) */ \
        CUPage k_page = pop_cuda_page(); \
        CUPage v_page = pop_cuda_page(); \
        /* 2. 遍历所有请求，将同一个物理页映射多次 (Multiple mappings) */ \
        for (int reqId = 0; reqId < max_batch_size; reqId++) { \
            /* 计算该请求对应的虚拟地址偏移 */ \
            req_offset = get_req_current_map_offset(reqId); \
            /* 映射：不同的虚拟地址 -> 同一个物理句柄 (Aliasing) */ \
            map_cuda_pages(reqId, layer_idx, req_offset, kcache_ptr, vcache_ptr, k_page, v_page); \
        } \
        } \
    } while (0)