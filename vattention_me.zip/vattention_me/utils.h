#include <vector>
#include <map>
#include <tuple>
#include <atomic>
#include <thread>
#include <iostream>
#include <cassert>
#include <cuda.h> // CUDA Driver API
#include <torch/extension.h> // 假设使用了 PyTorch binding

// ==========================================
// 1. 基础宏定义与工具
// ==========================================
#define KB (1024UL)
#define MB (1024 * KB)
#define GB (1024 * MB)

#define MAX(a, b) ((a) < (b) ? (b) : (a))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

// 核心宏：计算 KV Block 和 物理页(Page) 之间的转换关系
// 这里的逻辑假设：一个物理分配单元需要覆盖所有层(num_layers)的 K 和 V (系数2)
// kvblocks 可能指的是逻辑上的 Token 块数量
#define KVBLOCKS_TO_PAGES(kvblocks) ((kvblocks) * (2) * (num_layers))
#define PAGES_TO_KVBLOCKS(pages) ((pages) / (2 * (num_layers)))

// 内存对齐宏：将 x 向上取整到 y 的倍数
#define ROUND_UP(x, y) ((((x) + (y) - 1) / (y)) * (y))
// MegaCache 特有的转换宏（可能用于不同的缓存策略）
#define PAGES_TO_KVBLOCKS_MEGACACHE(pages) ((pages) / 2)

// 日志开关
bool verbose = false;

// ==========================================
// 2. 类型定义与全局变量
// ==========================================
typedef long long unsigned int NvU64;
typedef unsigned long u64;

// CUDA 驱动 API 上下文与属性
CUcontext ctx;
CUmemAllocationProp prop = {};   // 内存分配属性（如设备ID、内存类型）
CUmemAccessDesc accessDesc = {}; // 内存访问描述符（读写权限）

// 定义物理页句柄类型
typedef CUmemGenericAllocationHandle CUPage;

// 存储物理显存页的容器 使用 CUDA VMM API 分配的句柄
std::vector<CUmemGenericAllocationHandle> cuda_pages;


// 物理页映射表：用于在释放内存时查找对应的物理页句柄
// Key: tuple<请求ID/地址信息等> (具体含义取决于代码上下文，推测是虚拟地址段标识)
// Value: pair<句柄, 句柄> (可能分别对应 K 和 V，或者双缓冲)
using cudaPhysPageMap = std::map<std::tuple<u64, u64, u64>, std::pair<CUPage, CUPage>>;

cudaPhysPageMap cuda_pagemap;

// 设备指针，指向分配好的显存起始位置（长度 num_layers ）
std::vector<CUdeviceptr> k_ptr;
std::vector<CUdeviceptr> v_ptr;

// PyTorch Tensor 封装，用于上层 Python 调用，每一层一个 Tensor
std::vector<at::Tensor> k_tensors;
std::vector<at::Tensor> v_tensors;

// 线程同步标志：控制后台内存整理线程的启停
std::atomic<bool> mem_manager_running(false);

// ==========================================
// 3. 模型与框架参数
// ==========================================
/* 模型架构参数 */
int num_kv_heads;      // KV head 的数量 (通常等于 num_heads 或者更少 - MQA/GQA)
int head_size;         // 每个 head 的维度
int num_layers;        // Transformer 层数
int bytes_per_elem;    // 每个元素字节数 (FP16=2, FP32=4)
int device;            // GPU 设备 ID
py::object dtype;      // 数据类型

/* 推理框架参数 */
int max_batch_size;      // 最大支持的并发请求数 (Batch Size)
long max_context_length; // 最大上下文长度 (Context Window)

/* 虚拟内存元数据 */
u64 virt_buff_size;           // 整个虚拟缓冲区的大小(virt_buff_size_per_req * max_batch_size)
// 每个请求预留的虚拟地址空间大小（等于 virt_buff_size_per_token * max_context_length 上取整page_size倍数）
u64 virt_buff_size_per_req;   
u64 virt_buff_size_per_token; // 每个 Token 占用的虚拟内存大小（一层/所有层 的一个token的K/V)
u64 virt_buff_num_kv_tokens;  // 缓冲区总共能容纳的 KV Token 数(max_batch_size * max_context_length (* num_layers))

// tokens_per_page = page_size / virt_buff_size_per_token
u64 tokens_per_page; // 一个物理页(Block，2MB)能存多少个 Token (K / V)


/* 限制：一个请求最多能分配多少个物理页 */
u64 max_pages_per_req; //（virt_buff_size_per_req / page_size)

/* 物理内存元数据 - 核心状态跟踪 */
// index 为 reqId (Batch 中的索引，max_batch_size长度)
std::vector<u64> mapped_pages;     // 每个请求当前已分配(映射)的物理页数量（单位1表示一个token所有层的K和V）
std::vector<u64> curr_seq_lengths; // 每个请求当前的序列长度 (Token 数)

/* 垃圾回收线程：利用空闲时间整理内存 */
std::thread gc_thread;

/*
 * 延迟回收策略：
 * true: 仅在需要新内存时才回收旧内存
 * false: 立即回收
 */
bool deferred_reclaim = true;

/* 物理页大小，默认为 2MB (CUDA Huge Page) 以提高 TLB 命中率 */
u64 page_size = 2 * MB;


// ==========================================
// 4. 辅助函数实现
// ==========================================

// 初始化每个请求的 序列长度 和 映射页数 都为0
void init_kvcache_batch_metadata()
{
    mapped_pages.resize(max_batch_size);
    curr_seq_lengths.resize(max_batch_size);
    for (int i = 0; i < max_batch_size; i++)
    {
        curr_seq_lengths[i] = 0; // 初始序列长度为0
        mapped_pages[i] = 0;     // 初始未映射任何页
    }
}

// 配置检查：确保关键参数不为0
bool check_kvcache_config()
{
    return !(num_layers == 0 || num_kv_heads == 0 || head_size == 0 ||
             max_batch_size == 0 || max_context_length == 0);
}

// 计算所需的物理页数（一层/所有层的所有token的K/V）
// 向上取整除法： (tokens + block_size - 1) / block_size
inline u64 tokens_to_pages(u64 num_tokens)
{
    return (num_tokens + tokens_per_page - 1) / tokens_per_page;
}

// 计算页数对应的 Token 容量
inline u64 pages_to_tokens(u64 num_blocks)
{
    return num_blocks * tokens_per_page;
}

// 获取指定请求已映射的 Token 总容量
inline u64 get_req_mapped_tokens(int reqId)
{
    return pages_to_tokens(mapped_pages[reqId]);
}

// 获取指定请求已映射的物理页数 mapped_pages[reqId]
inline u64 get_req_pages(int reqId)
{
    return mapped_pages[reqId];
}

// ++mapped_pages[reqId];
inline u64 inc_req_page_count(int reqId)
{
    return ++mapped_pages[reqId];
}

// 减少指定请求的页计数 (释放了一页)
inline u64 dec_req_page_count(int reqId)
{
    return --mapped_pages[reqId];
}

// 计算指定请求的虚拟内存起始偏移量
// return reqId * virt_buff_size_per_req;
inline u64 get_req_begin_offset_virt(int reqId)
{
    return reqId * virt_buff_size_per_req;
}

// 判断请求是否活跃 (长度不为0)
inline bool is_active_req(int reqId)
{
    return curr_seq_lengths[reqId] != 0;
}

// return curr_seq_lengths[reqId]
inline u64 get_req_seq_length(int reqId)
{
    return curr_seq_lengths[reqId];
}

// curr_seq_lengths[reqId] = seq_len;
inline void set_req_seq_length(int reqId, u64 seq_len)
{
    curr_seq_lengths[reqId] = seq_len;
}

// 批量更新序列长度  curr_seq_lengths = seq_lens;
inline void set_curr_seq_lengths(std::vector<u64> seq_lens)
{
    curr_seq_lengths = seq_lens;
}

// 同步等待内存管理器
// 自旋锁，等待后台线程完成工作
inline void wait_kvcache_manager_sync()
{
    while (mem_manager_running)
        ;
}

// (未使用) 预设下一步的序列长度 (+1)
inline void set_seq_lengths_for_next_step(std::vector<u64> seq_lens)
{
    for (int reqId = 0; reqId < max_batch_size; reqId++)
    {
        if (!is_active_req(reqId))
            continue;
        set_req_seq_length(reqId, seq_lens[reqId] + 1);
    }
}

// 计算所有请求中“浪费”的物理块
// 已分配的容量 - 实际使用的长度 = 碎片/预留空间
inline u64 get_num_overcommitted_kvblocks()
{
    u64 overcommitted_kvblocks = 0;
    for (int reqId = 0; reqId < max_batch_size; reqId++)
        overcommitted_kvblocks += mapped_pages[reqId] - tokens_to_pages(get_req_seq_length(reqId));
    return overcommitted_kvblocks;
}

// 获取当前请求 **新分配页** 的虚拟地址结束偏移
// 用于 `cuMemMap` 映射操作
inline u64 get_req_current_map_offset(int reqId)
{
    u64 num_mapped_blocks = get_req_pages(reqId);
    // 偏移量 = 已映射块数 * 页大小
    u64 block_offset_within_req = num_mapped_blocks * page_size;

    return get_req_begin_offset_virt(reqId) + block_offset_within_req;
}

// 获取当前请求 **最后一个已分配页** 的虚拟地址起始偏移
// 用于 `cuMemUnmap` 操作 (从尾部开始释放)
inline u64 get_req_current_unmap_offset(int reqId)
{
    u64 num_mapped_blocks;
    u64 block_offset_within_req;

    num_mapped_blocks = get_req_pages(reqId);
    /* 如果没有映射任何页，不能调用 unmap */
    assert(num_mapped_blocks > 0);
    /* 返回最后一个 Block 的起始位置 */
    block_offset_within_req = (num_mapped_blocks - 1) * page_size;
    return get_req_begin_offset_virt(reqId) + block_offset_within_req;
}

// 核心逻辑：异步预判是否需要分配新页
// 参数 eager_step_count: 预测未来生成的 Token 数 (预分配步长)
// 返回值: 需要分配的页数 (通常是 0 或 1)
u64 need_new_page_async(int reqId, int eager_step_count)
{
    if (!is_active_req(reqId))
        return 0;

    /* 达到最大页限制，不再分配，可能需要 Evict 或报错 */
    u64 nr_mapped = get_req_pages(reqId);
    if (nr_mapped == max_pages_per_req)
        return 0;

    /* * 预测逻辑：当前长度 + 预测步长
     * 如果 (当前长度 + 预测步长) 需要的页数 > 当前已映射页数，则需要分配
     */
    u64 nr_required = tokens_to_pages(get_req_seq_length(reqId) + eager_step_count);
    return nr_required <= nr_mapped ? 0 : nr_required - nr_mapped;
}

// 计算可用显存能切分出的物理 Block 数量
// 这里的约束是：物理 Block 必须能被 (2 * num_layers) 整除？
// 或者是为了保证多层之间的内存对齐？
u64 get_num_phys_blocks(u64 num_layers, u64 free_memory, u64 page_size)
{
    u64 num_phys_blocks;
    /* 计算总页数 */
    num_phys_blocks = free_memory / page_size;
    /* 向下对齐到 (2 * num_layers) 的倍数 */
    /* 这暗示了分配粒度不仅仅是一个 Page，可能是一组 Page 对应所有层 */
    num_phys_blocks -= num_phys_blocks % (2 * num_layers);
    return num_phys_blocks;
}

// 简单的日志类
class Log
{
public:
    void log(const std::string &msg)
    {
        if (verbose)
            std::cout << msg << std::endl;
    }
};