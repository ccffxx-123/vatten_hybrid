#include <torch/extension.h>
#include <torch/types.h>
#include <ATen/ATen.h>
#include <ATen/cuda/EmptyTensor.h>
#include <ATen/ScalarType.h>
#include <ATen/ArrayRef.h>
#include <ATen/Tensor.h>
#include <c10/cuda/CUDAStream.h>
#include <c10/core/DeviceGuard.h>
#include <c10/cuda/CUDACachingAllocator.h>
#include <c10/util/static_tracepoint.h>
#include <vector>
#include <cuda_runtime.h>
#include <cuda.h>
#include <Python.h>
#include <utility>

#include <thread>
#include <atomic>

#include "utils.h"
#include "cudaInternal.h"
#include "mux.h"
#include "vtensor.h"

class vAttentionCachingAllocator
{
private:
    /* whether kv cache has been configured yet */
    bool is_configured = false;
    /* custom virtual tensor allocator */
    VirtualTensorAllocator *allocator;
    Log log;

public:
    // 决定了KV存储是否按层存储
    bool megacache_enabled;
    
    // 初始化 后端 CUDA
    // 计算 token_per_page （可能需要改，根据不同层进行设计）
    void init_kv_block_size()
    {
        page_size = do_cuda_default_init(device, page_size);
        tokens_per_page = page_size / (num_kv_heads * head_size * bytes_per_elem * num_layers);
        log.log("Initialized CUDA context and memory config etc...");
        log.log("num_tokens_per_kvblock: " + std::to_string(tokens_per_page));
    }

    // 计算虚拟缓冲区大小（按照最大情况来算）
    void init_buffer_sizes()
    {
        u64 remainder;

        virt_buff_size_per_token = num_kv_heads * head_size * bytes_per_elem * num_layers;
        virt_buff_size_per_req = virt_buff_size_per_token * max_context_length;
        virt_buff_size_per_req = ROUND_UP(virt_buff_size_per_req, page_size);

        max_pages_per_req = virt_buff_size_per_req / page_size;

        /* align to ensure that each request begins at a mappable offset */
        remainder = virt_buff_size_per_req % page_size;
        if (remainder != 0)
            virt_buff_size_per_req += page_size - remainder;

        virt_buff_size = virt_buff_size_per_req * max_batch_size;
        virt_buff_num_kv_tokens = max_batch_size * max_context_length * num_layers;
        log.log("virt_buff_num_kv_tokens: " + std::to_string(virt_buff_num_kv_tokens));
        log.log("virt_buff_size_per_req: " + std::to_string(virt_buff_size_per_req / MB) + " MB");
        log.log("virt_buff_size: " + std::to_string(virt_buff_size / MB) + " MB");
    }
    
    // 打印当前显存池的剩余库存，以及当前正在处理的每一个请求（Request）的显存占用情况。
    inline void show_allocator_state()
    {
        std::stringstream ss;
        u64 nr_pages = cuda_pages.size();
        log.log("Free pool: " + std::to_string(PAGES_TO_KVBLOCKS_MEGACACHE(nr_pages)) + " KV blocks");

        log.log("reqId : seqlen: mapped: required");
        for (int i = 0; i < max_batch_size; i++)
        {
            ss.str(std::string());
            ss << std::setw(8) << i << ": "
               << std::setw(8) << get_req_seq_length(i) << " : "
               << std::setw(8) << mapped_pages[i] << " : "
               << std::setw(8) << tokens_to_pages(get_req_seq_length(i));
            log.log(ss.str());
        }
    }

    // 初始化 KV Cache（总，起点）
    void init_kvcache(int num_layers_,
                      int num_kv_heads_,
                      int head_size_,
                      int max_batch_size_,
                      long max_context_length_,
                      int device_,
                      py::object dtype_,
                      u64 page_size_,
                      bool megacache)
    {
        assert(max_batch_size_ > 0 && max_batch_size_ < 1000);
        assert(max_context_length_ > 0 && max_context_length_ < 1000000);
        assert(num_layers_ > 0 && num_layers_ < 100);
        assert(num_kv_heads_ > 0 && num_kv_heads_ < 256);
        num_layers = num_layers_;
        num_kv_heads = num_kv_heads_;
        head_size = head_size_;
        max_batch_size = max_batch_size_;
        max_context_length = max_context_length_;
        device = device_;
        dtype = dtype_;
        page_size = page_size_;
        // megacache_enabled = megacache;
        megacache_enabled = true;
        bytes_per_elem = dtype.attr("itemsize").cast<int>();

        init_kv_block_size();          // 计算 一个页最多存多少个token
        init_buffer_sizes();           // 计算虚拟缓冲区大小（按照最大情况来算）
        init_kvcache_batch_metadata(); // 初始化每个请求的 序列长度 和 映射页数 都为0
        k_ptr.resize(num_layers);
        v_ptr.resize(num_layers);
        allocator = new VirtualTensorAllocator(device, page_size);
        is_configured = true;
    }

    void show_kvcache_config()
    {
        log.log("Num layers: " + std::to_string(num_layers));
        log.log("Num kv_heads: " + std::to_string(num_kv_heads));
        log.log("Head size: " + std::to_string(head_size));
        log.log("Max batch size: " + std::to_string(max_batch_size));
        log.log("Max context length: " + std::to_string(max_context_length));
        log.log("Bytes per elem: " + std::to_string(bytes_per_elem));
        log.log("virt_buff_size_per_req: " + std::to_string(virt_buff_size_per_req));
        log.log("virt_buff_size: " + std::to_string(virt_buff_size));
        log.log("tokens_per_page: " + std::to_string(tokens_per_page));
    }


    // 分配虚拟张量
    at::Tensor alloc_virtual_tensor()
    {
        at::ScalarType type_ = torch::python::detail::py_object_to_dtype(dtype); //C++ type
        at::IntArrayRef shape; //tensor形状 (AB 层，1 2 token)
        
        shape = {max_batch_size, max_context_length, num_layers, num_kv_heads, head_size}; //[ A1, B1, A2, B2, A3, B3, ... ]

        at::Tensor t = alloc_vtensor(shape, page_size, type_, allocator, device);
        return t;
    }

    // 初始化 KV Cache 虚拟张量
    std::vector<at::Tensor> init_kvcache_virtual()
    {
        if (!check_kvcache_config())
        {
            log.log("Invalid kv cache configuration...");
            return std::vector<at::Tensor>();
        }

        
        at::Tensor t0 = alloc_virtual_tensor();
        at::Tensor t1 = alloc_virtual_tensor();
        k_tensors.push_back(t0);
        v_tensors.push_back(t1);

        std::vector<at::Tensor> tensors;
        tensors.insert(tensors.end(), k_tensors.begin(), k_tensors.end());
        tensors.insert(tensors.end(), v_tensors.begin(), v_tensors.end());
        return tensors; //{kcache,vcache}
    }

    u64 reserve_physical_pages(u64 free_memory)
    {
        return reserve_cuda_pages(num_layers, free_memory, page_size);
    }

    // 计算当前可用的物理块数量（free as well as overcommitted）
    inline u64 get_num_free_kvblocks()
    {
        u64 free_kvblocks;

        // 整个的token（所有层）为最小单位
        free_kvblocks = PAGES_TO_KVBLOCKS_MEGACACHE(cuda_pages.size());

        return free_kvblocks + get_num_overcommitted_kvblocks();
    }

    /* check pages that are free as well as overcommitted */
    u64 num_free_kvblocks()
    {
        return get_num_free_kvblocks();
    }

    // 检查是否有足够的 KV 块可用
    inline bool kvblocks_available(u64 num_kvblocks)
    {
        return PAGES_TO_KVBLOCKS_MEGACACHE(cuda_pages.size()) >= num_kvblocks ? true : false;
    }

    // 释放请求的最后一个token对应的KV块
    inline void unmap_req_page_one(int reqId)
    {
        u64 req_offset;
        req_offset = get_req_current_unmap_offset(reqId);

        CUdeviceptr kcache_ptr = reinterpret_cast<CUdeviceptr>(k_tensors[0].data_ptr());
        CUdeviceptr vcache_ptr = reinterpret_cast<CUdeviceptr>(v_tensors[0].data_ptr());
        UNMAP_PAGES(reqId, 0, req_offset, kcache_ptr, vcache_ptr, page_size);
        dec_req_page_count(reqId);
    }

    // 从后释放请求的部分 KV 块，直到只剩下 retain_blocks 个块
    inline void release_kvcache_pages_some(int reqId, u64 retain_blocks)
    {
        while (get_req_pages(reqId) > retain_blocks)
            unmap_req_page_one(reqId);
    }

    // 释放请求的所有 KV 块
    inline void release_kvcache_pages_all(int reqId)
    {
        release_kvcache_pages_some(reqId, 0);
    }

    // 检查请求偏移量是否合法（小于预留的该请求的大小）
    inline bool is_valid_offset(int reqId, u64 req_offset, bool sync)
    {
        if (req_offset < (reqId + 1) * virt_buff_size_per_req)
            return true;

        /* for async allocation attempts, it is enough to simply return */
        if (!sync)
            return false;

        std::runtime_error("***** [Unexpected] request has already received max number of pages *****");
        return false;
    }

    /* Grow KV cache physical memory allocation by num_blocks */
    /*将物理显存真正分配给某个请求。*/
    // 一层的K / V 1个页，
    void grow_kvcache_phys(int reqId, u64 num_blocks, bool sync)
    {
        u64 req_offset;
        at::Storage k_storage, v_storage;

        if (num_blocks <= 0)
            return;

        if (!kvblocks_available(num_blocks))
        {
            /* no-op if this is being called by the background thread. */
            if (!sync)
                return;

            /* there is no other option but to abort */
            verbose = true;

            log.log("free pages: " + std::to_string(PAGES_TO_KVBLOCKS_MEGACACHE(cuda_pages.size())));
            log.log("required: " + std::to_string(num_blocks));

            show_allocator_state();
            throw std::runtime_error("***** OOM on demand: not enough free pages to continue *****");
            return;
        }

        for (int count = 0; count < num_blocks; count++)
        {
            req_offset = get_req_current_map_offset(reqId);  // 当前请求末尾虚拟地址
            if (!is_valid_offset(reqId, req_offset, sync))
                return;

            CUdeviceptr kcache_ptr = reinterpret_cast<CUdeviceptr>(k_tensors[0].data_ptr());
            CUdeviceptr vcache_ptr = reinterpret_cast<CUdeviceptr>(v_tensors[0].data_ptr());
            MAP_PAGES(reqId, 0, req_offset, kcache_ptr, vcache_ptr, page_size);
            inc_req_page_count(reqId);
        }
    }

    /* This is only to validate that same physical page can be given to multiple requests */
    /*对于 Batch 中所有请求都相同的那些 Token（比如巨大的 System Prompt），只分配一份物理显存，
    然后把这份显存映射到所有请求的虚拟地址空间中去。*/
    void map_common_pages_in_batch(u64 num_tokens)
    {
        u64 req_offset, num_blocks;
        at::Storage k_storage, v_storage;

        num_blocks = tokens_to_pages(num_tokens);
        if (num_blocks <= 0)
            return;

        if (!kvblocks_available(num_blocks))
        {
            
            log.log("free pages: " + std::to_string(PAGES_TO_KVBLOCKS_MEGACACHE(cuda_pages.size())));
            log.log("required: " + std::to_string(num_blocks));

            throw std::runtime_error("***** OOM on demand: not enough free pages to continue *****");
            return;
        }

        for (int count = 0; count < num_blocks; count++)
        {
            CUdeviceptr kcache_ptr = reinterpret_cast<CUdeviceptr>(k_tensors[0].data_ptr());
            CUdeviceptr vcache_ptr = reinterpret_cast<CUdeviceptr>(v_tensors[0].data_ptr());
            MAP_COMMON_PAGES(0, kcache_ptr, vcache_ptr, page_size);
            for (int reqId = 0; reqId < max_batch_size; reqId++)
                inc_req_page_count(reqId);
        }
    }

    /* Map physical memory for the current iteration before returning control */
    /*后台的预取线程可能偷懒了，或者显存太挤了。不管怎样，马上就要开始计算了，
    我必须在 Kernel 启动前最后确认一遍显存够不够。不够的话，
    就算要把别人的空闲地皮抢过来（Reclaim），我也得把这块内存给补上。*/
    void map_pages_for_curr_step(int reqId, u64 seq_len)
    {
        u64 nr_required = tokens_to_pages(seq_len);
        u64 nr_mapped = get_req_pages(reqId);

        if (nr_required <= nr_mapped)
            return;

        nr_required -= nr_mapped;
        if (!kvblocks_available(nr_required))
            reclaim_kvblocks_on_demand(nr_required);

        /* this should not get triggered frequently with our optimizations */
        log.log("[DEBUG] allocating " + std::to_string(nr_required) + " pages for reqId: " + std::to_string(reqId));
        grow_kvcache_phys(reqId, nr_required, true);
        set_req_seq_length(reqId, seq_len);
    }

    /* This is not meant for final use but to test vattention with sync allocation */
    /* 用于同步分配的 vattention 测试 */
    void step_sync(std::vector<u64> seq_lens, bool eager_reclaim)
    {
        for (int reqId = 0; reqId < max_batch_size; reqId++)
        {
            /* set the sequence length based on latest values coming from the framework */
            set_req_seq_length(reqId, seq_lens[reqId]);
            /* request not active but physical memory blocks are allocated */
            if (eager_reclaim == true and (seq_lens[reqId] == 0 && mapped_pages[reqId] != 0))
            {
                release_kvcache_pages_all(reqId);
                continue;
            }
            map_pages_for_curr_step(reqId, seq_lens[reqId]);
        }
    }

    /* Ensure that we have enough pages for each new sequence */
    /* 为每个新序列确保有足够的页面 */
    void prepare_prefill_kvcache()
    {
        for (int reqId = 0; reqId < max_batch_size; reqId++)
        {
            map_pages_for_curr_step(reqId, get_req_seq_length(reqId));
        }
    }

    // 遍历request，释放映射但未使用的页 直到满足需求
    void reclaim_kvblocks_on_demand(u64 num_kvblocks)
    {
        u64 nr_mapped, nr_required;

        /* now we get into relaim mode */
        for (int reqId = max_batch_size - 1; reqId >= 0; reqId--)
        {
            /* demand fulfilled */
            if (kvblocks_available(num_kvblocks))
                break;

            nr_mapped = get_req_pages(reqId);
            nr_required = tokens_to_pages(get_req_seq_length(reqId));
            if (nr_mapped <= nr_required)
                continue;

            release_kvcache_pages_some(reqId, nr_required);
        }
    }

    /*
     * Release one page at a time (in the order opposite to how we allocated a new request id)
     * We do not reclaim from the req id that we know is going to be allocated soon
     */
    /*统空闲时，逐步释放那些“已经结束但还占用着物理页”的非活跃请求的显存，以便将物理页归还给公共池
    它采用了时间分片的策略，每次只回收一页就停手，防止影响主线程性能*/
    void do_reclaim_pages()
    {
        if (deferred_reclaim)
            return;

        int next_prefill_reqId = -1;

        for (int reqId = 0; reqId < max_batch_size; reqId++)
        {
            if (!is_active_req(reqId))
            {
                next_prefill_reqId = reqId;
                break;
            }
        }

        for (int reqId = max_batch_size - 1; reqId >= 0; reqId--)
        {
            if (is_active_req(reqId) || reqId == next_prefill_reqId)
                continue;
            if (get_req_pages(reqId) == 0)
                continue;
            unmap_req_page_one(reqId);
            break;
        }
    }

/*
 * 1. Check how many new pages will be required in the next step
 * 2. Ensure that the free pool is large enough, reclaim memory if required
 * 3. Allocate memory for the next step.
 *
 * If new blocks are not required, we free one block in an iteration (in the decreasing order of reqIds)
 * If new blocks are required, free as many blocks as required + some more so that next prefill can also be handled
 * TODO: check corner-cases e.g., what if only one inactive reqId has pages mapped? we could probably not relaim in
 * this case so that next prefill can re-use already allocated memory.
 */

/*
 * These are based on heuristics and should be fine for most cases.
 * Configure if needed.
 * @brief 后台显存管理主程序：执行“刚需分配”、“预取优化”与“闲时回收”。
 * * 核心逻辑：
 * 1. 生存检查：计算下一时刻所有请求的硬性显存缺口，库存不足则强制回收。
 * 2. 分级分配：
 * - 优先满足所有请求第 1 步的刚需（无视限额）。
 * - 尝试预取未来 N 步的显存，但受分配数量限制（Throttle），防止卡顿。
 * 3. 闲时回收：如果当前没有刚需分配任务，则清理非活跃请求的显存。
 */
#define EAGER_NUM_STEPS (10)
#define EAGER_NUM_KVBLOCKS (2)
    void do_kvcache_memory_management()
    {
        u64 nr_required = 0;
        u64 nr_mapped_curr = 0;
        bool done = false;

        for (int reqId = 0; reqId < max_batch_size; reqId++)
            nr_required += need_new_page_async(reqId, 1);

        if (!kvblocks_available(nr_required))
        {
            log.log("[DEBUG] reclaiming " + std::to_string(nr_required) + " KV blocks in background thread...");
            reclaim_kvblocks_on_demand(nr_required);
        }

        /*
         * Check if we have enough free pages to continue. If not, we return without doing
         * anything, hoping that memory will become available when some request exits.
         */

        if (!kvblocks_available(nr_required))
            return;

        for (int eager_step_count = 1; eager_step_count < EAGER_NUM_STEPS && !done; eager_step_count++)
        {
            for (int reqId = 0; reqId < max_batch_size; reqId++)
            {
                u64 nr_required_curr = need_new_page_async(reqId, eager_step_count);
                grow_kvcache_phys(reqId, nr_required_curr, false);
                nr_mapped_curr += nr_required_curr;
                if (eager_step_count == 1)
                    continue;
                if (nr_mapped_curr >= EAGER_NUM_KVBLOCKS)
                {
                    done = true;
                    break;
                }
            }
        }

        /*
         * Doing too much work in one iteration can impact latency, so we
         * return without attemtping reclamation if we just allocated one or more pages.
         */
        if (nr_required)
            return;

        do_reclaim_pages();
    }

    //按需启动的后台辅助机制。do_kvcache_memory_management 的线程包装器。
    void spawn_kvcache_manager()
    {
        std::thread([this]()
                    {
            mem_manager_running = true;
            do_kvcache_memory_management();
            mem_manager_running = false; })
            .detach();
    }

    /* single step for asynchronous allocation */
    /*标准异步步进函数。它完美展示了 CPU/GPU 流水线并行（Pipeline Parallelism） 的设计思想：
    在 GPU 疯狂计算当前这一步的同时，利用 CPU 的空闲时间去准备下一步的显存。*/
    void step_async(std::vector<u64> seq_lens)
    {
        set_curr_seq_lengths(seq_lens);
        /* synchronize with the background thread first */
        wait_kvcache_manager_sync();
        /* allocate prefill memory synchronously, if required */
        prepare_prefill_kvcache();
        /* allocate decode memory for next step asynchronously */
        spawn_kvcache_manager();
    }

    /*
     * Return one of the inactive ids using best fit.
     * NOTE: the caller is supposed to check if the returned reqId is valid or not
     * 在新请求进来时，试图找到一个“最合适”的空闲槽位（Slot），尽可能复用该槽位上残留的物理页，
     */
    int alloc_new_batch_idx(u64 seqlen)
    {
        int new_id = -1;
        u64 nr_required = tokens_to_pages(seqlen);

        for (int reqId = 0; reqId < max_batch_size; reqId++)
        {
            if (is_active_req(reqId))
                continue;

            if (new_id == -1)
            {
                new_id = reqId;
                continue;
            }

            if (get_req_pages(reqId) >= nr_required &&
                get_req_pages(reqId) < get_req_pages(new_id))
                new_id = reqId;
        }

        if (new_id != -1)
            set_req_seq_length(new_id, seqlen);

        return new_id;
    }

    // 释放请求，置其len为0
    void free_batch_idx(int reqId)
    {
        set_req_seq_length(reqId, 0);
    }

    // 设置是否延迟回收显存
    void set_deferred_reclamation(bool val)
    {
        deferred_reclaim = val;
    }

    /* TODO(ashish): check if this is compatible with PyTorch destructor */
    void cleanup()
    {
        wait_kvcache_manager_sync();
        DO_KVCACHE_CLEANUP(page_size);
        k_tensors.clear();
        v_tensors.clear();
        log.log("released memory and cleaned up vattention ...");
    }
};

#include "apis.h"

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m)
{
    /*
     * These must be invoked during initialization/termination
     * TODO(ashish): Merge these into one API?
     */
    m.def("reserve_physical_pages", &reserve_physical_pages, "reserve physical memory blocks...");
    // m.def("init_kvcache", &init_kvcache, "initialize KV cache...");
    m.def("cleanup", &cleanup, "cleanup and release allocator resources context...");
    /* Tunables and other helper APIs */
    m.def("set_verbose", &set_verbose, "to enable/disable printing logs...");
    m.def("set_deferred_reclamation", &set_deferred_reclamation, "enable/disable deferred freeing...");
    /* Testing APIs */
    m.def("show_kvcache_config", &show_kvcache_config, "show kv cache configuration...");
    m.def("show_allocator_state", &show_allocator_state, "show free pool of physical memory blocks...");
    m.def("step", &step, "step function...");
    m.def("map_common_pages", &map_common_pages, "map common pages in batch...");
    /* API for actual physical memory allocation - one call per iteration */
    m.def("step_async", &step_async, "single step function for the async version...");
    /* Request-level APIs */
    m.def("alloc_new_batch_idx", &alloc_new_batch_idx, "allocate a request id...");
    m.def("free_batch_idx", &free_batch_idx, "free a request id...");
    m.def("num_free_kvblocks", &num_free_kvblocks, "number of free kv blocks...");
}

